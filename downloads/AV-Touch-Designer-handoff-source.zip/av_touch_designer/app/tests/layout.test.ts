import {test} from 'node:test';
import assert from 'node:assert/strict';
import {arrange,reflow,addTemplate,type Project,type Element} from '../src/layout.ts';
const e=(id:string,x:number,y:number,width=100,height=60):Element=>({id,type:'button',x,y,width,height,zIndex:2,locked:false,props:{text:id}});
const p=(elements:Element[]):Project=>({canvas:{width:1280,height:800},pages:[{id:'main',elements}],popups:[],stateDefinitions:[]});
test('center alignment uses combined bounds and excludes locked items',()=>{const a=e('a',10,20),b=e('b',310,220,200,80),locked={...e('lock',1000,0),locked:true};const r=arrange(p([a,b,locked]),'main',['a','b','lock'],'centerX');assert.deepEqual(r.pages[0].elements.map(e=>e.x),[210,160,1000]);});
test('grid supports unequal sizes with explicit gap; bounds error is atomic',()=>{const original=p([e('a',10,20,100),e('b',300,200,150),e('c',600,400,80)]);const r=arrange(original,'main',['a','b','c'],'grid',24,2);assert.deepEqual(r.pages[0].elements.map(e=>[e.x,e.y]),[[10,20],[134,20],[10,104]]);assert.throws(()=>arrange({...original,canvas:{width:700,height:800}},'main',['a','b','c'],'row',200));assert.equal(original.pages[0].elements[1].x,300);});
test('legacy responsive panel leaves internal geometry unchanged',()=>{const panel={...e('panel',10,20,400,300),type:'panel',zIndex:1,props:{responsive:true}};const original=p([panel,e('child',50,80),e('outside',500,80)]);const next=p([{...panel,x:30,width:800,height:600},...original.pages[0].elements.slice(1)]);const r=reflow(original,next);assert.deepEqual([r.pages[0].elements[1].x,r.pages[0].elements[1].y,r.pages[0].elements[1].width,r.pages[0].elements[1].height],[50,80,100,60]);assert.deepEqual(r.pages[0].elements[2],original.pages[0].elements[2]);assert.deepEqual(reflow(original,next),r);});
test('locked content does not block independent panel resize',()=>{const panel={...e('panel',0,0,400,300),type:'panel',zIndex:1,props:{responsive:true}};const original=p([panel,{...e('child',50,80),locked:true}]);assert.doesNotThrow(()=>reflow(original,p([{...panel,width:800},original.pages[0].elements[1]])));assert.doesNotThrow(()=>reflow(original,{...original,pages:[]}));});
test('template creates independent state bindings and checks fit and counts',()=>{let n=0;const uid=()=>`id_${++n}`;const r=addTemplate(p([]),'main',5,2,uid);assert.equal(r.ids.length,4);assert.equal(r.project.stateDefinitions.length,5);assert.equal((r.project.pages[0].elements[1].props.options as unknown[]).length,5);assert.equal(new Set(r.project.stateDefinitions.map(d=>d.key)).size,5);assert.throws(()=>addTemplate(p([]),'main',8,8,uid),/収まり/);assert.throws(()=>addTemplate(p([]),'main',0,0,uid));});

test('startup reuses one page, sets startup/ON/OFF routes and keeps independent power keys',async()=>{
 const {addStartup}=await import('../src/layout.ts');let id=0;const uid=(prefix='id')=>`${prefix}_${++id}`;
 const original=p([{...e('power',32,100,320,120),type:'powerControl',props:{powerStateKey:'power',popupId:'confirm'}}]);original.stateDefinitions=[{key:'power',type:'boolean',initialValue:true}];original.popups=[{id:'confirm',elements:[{...e('yes',24,100),interactions:{onTap:[{type:'setValue',stateKey:'power',value:false},{type:'closePopup'}]}}]}];
 const result=addStartup(original,'main',uid);assert.equal(result.project.startPageId,result.pageId);assert.equal(result.project.pages.filter(page=>page.role==='startup').length,1);assert.equal(result.project.stateDefinitions[0].initialValue,false);
 const startup=result.project.pages.find(page=>page.id===result.pageId)!;const launch=startup.elements.find(e=>e.type==='button')!;const actions=(launch.interactions as {onTap:unknown[]}).onTap;
 assert.deepEqual(actions,[{type:'setValue',stateKey:'power',value:true},{type:'navigate',pageId:'main'}]);assert.deepEqual((result.project.popups[0].elements[0].interactions as {onTap:unknown[]}).onTap.at(-1),{type:'navigate',pageId:result.pageId});
 const again=addStartup(result.project,'main',uid);assert.equal(again.project.pages.length,2);assert.equal(again.pageId,result.pageId);assert.equal(original.pages.length,1);assert.equal(original.stateDefinitions[0].initialValue,true);
});
test('standby template fits the smallest supported canvas and page limit is atomic',async()=>{
 const {addStartup}=await import('../src/layout.ts');let id=0;const uid=(prefix='id')=>`${prefix}_${++id}`;const small={...p([]),canvas:{width:320,height:240}};const r=addStartup(small,'main',uid);const page=r.project.pages.find(p=>p.role==='startup')!;
 for(const e of page.elements){assert(e.x>=0&&e.y>=0);assert(e.x+e.width<=320&&e.y+e.height<=240)}
 const full={...p([]),pages:Array.from({length:30},(_,i)=>({id:`p${i}`,elements:[]}))};assert.throws(()=>addStartup(full,'p0',uid),/30/);assert.equal(full.pages.length,30);
});

test('source layout preserves options, bindings, conditions, and interactions',async()=>{
 const {changeComponentLayout}=await import('../src/layout.ts');const source={...e('sources',40,100,640,112),type:'sourceSelector',props:{stateKey:'video',options:[1,2,3,4].map(value=>({label:`映像${value}`,value}))},interactions:{onTap:[{type:'setValue',stateKey:'other',value:1}]},disabledWhen:{stateKey:'power',equals:false}};const original=p([source]);const next=changeComponentLayout(original,'main','sources',2),changed=next.pages[0].elements[0];assert.equal(changed.props.columns,2);assert.equal(changeComponentLayout(next,'main','sources',4).pages[0].elements[0].height,112);assert.deepEqual(changed.props.options,source.props.options);assert.equal(changed.props.stateKey,'video');assert.deepEqual(changed.interactions,source.interactions);assert.deepEqual(changed.disabledWhen,source.disabledWhen);assert.deepEqual(next.stateDefinitions,original.stateDefinitions);assert.equal(source.props.columns,undefined);assert.throws(()=>changeComponentLayout(original,'main','sources',5));
});
test('volume orientation preserves control state and rejects unfit geometry atomically',async()=>{
 const {changeComponentLayout}=await import('../src/layout.ts');const volume={...e('volume',700,100,480,112),type:'volume',props:{label:'音声',stateKey:'gain',muteStateKey:'mute',showValue:true},interactions:{onTap:[]}};const original=p([volume]);const vertical=changeComponentLayout(original,'main','volume','vertical'),v=vertical.pages[0].elements[0];assert(v.width>=96&&v.height>=240);assert.equal(v.props.stateKey,'gain');assert.equal(v.props.muteStateKey,'mute');assert.equal(v.props.orientation,'vertical');assert.equal((changeComponentLayout(vertical,'main','volume','horizontal')).pages[0].elements[0].props.orientation,'horizontal');assert.throws(()=>changeComponentLayout({...original,canvas:{width:320,height:240}},'main','volume','vertical'),/収まり/);assert.equal(original.pages[0].elements[0].props.orientation,undefined);
});
test('state choices expose friendly names and retain long legacy reference keys',async()=>{
 const {stateChoices}=await import('../src/layout.ts');const key='audio_0123456789abcdef0123456789abcdef';const original=p([{...e('audio',0,0,300,112),type:'volume',props:{label:'会議室マイク',stateKey:key,muteStateKey:'muted'}}]);original.stateDefinitions=[{key,type:'number',initialValue:50},{key:'muted',type:'boolean',initialValue:false}];const choices=stateChoices(original);assert.equal(choices[0].key,key);assert.match(choices[0].label,/会議室マイク.*音量/);assert.equal(choices[1].label,'ミュート');
});

test('batch size/direction is atomic and preserves bindings and legacy panel children',async()=>{
 const {resizeMany}=await import('../src/layout.ts');const original=p([{...e('panel',0,0,700,600),type:'panel',props:{responsive:true}},...['a','b'].map((id,i)=>({...e(id,40+i*300,100,260,112),type:'volume',props:{stateKey:id,muteStateKey:'mute'}}))]);
 const r=resizeMany(original,'main',['a','b'],120,280,'vertical');assert(r.pages[0].elements.slice(1).every(e=>e.width===120&&e.height===280&&e.props.orientation==='vertical'));assert.equal(r.pages[0].elements[1].props.stateKey,'a');assert.deepEqual(r.stateDefinitions,original.stateDefinitions);
 assert.throws(()=>resizeMany(original,'main',['a','b'],100,100,'vertical'));assert.throws(()=>resizeMany(original,'main',['a','b'],1200,280,'vertical'));assert.equal(original.pages[0].elements[1].width,260);
 const locked=structuredClone(original);locked.pages[0].elements[2].locked=true;assert.throws(()=>resizeMany(locked,'main',['a','b'],120,280,'vertical'),/ロック/);
});

test('group scaling uses combined bounds, preserves actions, and rejects undersized or locked children atomically',async()=>{
 const {resizeSelection,resizeSelectionDrag}=await import('../src/layout.ts');const original=p([e('a',40,40,100,60),e('b',240,40,100,60),e('outside',800,40)]);
 const next=resizeSelection(original,'main',['a','b'],{x:40,y:40,width:600,height:120});assert.deepEqual(next.pages[0].elements.slice(0,2).map(e=>[e.x,e.y,e.width,e.height]),[[40,40,200,120],[440,40,200,120]]);assert.deepEqual(next.pages[0].elements[2],original.pages[0].elements[2]);
 assert.deepEqual(resizeSelectionDrag(original,'main',['a','b'],300,60,'se'),next);assert.throws(()=>resizeSelection(original,'main',['a','b'],{x:40,y:40,width:30,height:10}),/最小/);assert.equal(original.pages[0].elements[0].width,100);
 const locked=structuredClone(original);locked.pages[0].elements[1].locked=true;assert.throws(()=>resizeSelection(locked,'main',['a','b'],{x:40,y:40,width:600,height:120}),/ロック/);
});
test('drop placement moves only added members, clamps to canvas and preserves relative layout',async()=>{
 const {placeAdded}=await import('../src/layout.ts');const before=p([e('old',0,0)]),after=p([...before.pages[0].elements,e('a',16,16),e('b',140,16)]);
 const placed=placeAdded(before,after,'main',{x:1200,y:790});assert.deepEqual(placed.pages[0].elements[0],before.pages[0].elements[0]);assert.equal(placed.pages[0].elements[2].x-placed.pages[0].elements[1].x,124);assert.equal(placed.pages[0].elements[2].x+100,1280);assert.equal(placed.pages[0].elements[1].y+60,800);
});
test('switching configuration applies one group and limit without changing existing event arrays',async()=>{
 const {configureSwitching,ungroupSelection}=await import('../src/layout.ts');const a={...e('a',40,40),interactions:{onTap:[{type:'navigate',pageId:'other'}]}},original=p([a,e('b',240,40)]);const next=configureSwitching(original,'main',['a','b'],'group_1','toggle',1,500);
 assert(next.pages[0].elements.every(e=>(e.props.simple as {group:string;maxOn:number}).group==='group_1'&&(e.props.simple as {maxOn:number}).maxOn===1));assert.deepEqual(next.pages[0].elements[0].interactions,a.interactions);assert.throws(()=>configureSwitching(original,'main',['a','b'],'g','toggle',3,0));assert.equal(original.pages[0].elements[0].props.simple,undefined);const ungrouped=ungroupSelection({...next,groups:[{id:'group_1',memberIds:['a','b']}]},['a','b']);assert.deepEqual(ungrouped.groups,[]);assert(ungrouped.pages[0].elements.every(e=>(e.props.simple as {group:string}).group===''));
});
